<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <?php echo $__env->make('include.backend.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body class="text-capitalize <?php echo e((Auth::guard('admin')->user()->sidebar_size == 1) ? 'sidebar-mini' : ''); ?>">
    <div class="text-center spinner-overlay">
        <div class="spinner-grow spinner text-<?php echo e($theme); ?>" role="status" >
            <span class="sr-only">Loading...</span>
        </div>
    </div>
<div class="wrapper ">
    <?php echo $__env->make('include.backend.admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="main-panel">
        <?php echo $__env->make('include.backend.admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <style>
            .main-panel .content {
                padding-bottom: 0px !important;
                margin-bottom: 0px !important

            }
        </style>
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('include.backend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>


    <?php echo $__env->make('include.backend.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('include.backend.admin.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('script'); ?>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\projecto\resources\views/layouts/admin.blade.php ENDPATH**/ ?>