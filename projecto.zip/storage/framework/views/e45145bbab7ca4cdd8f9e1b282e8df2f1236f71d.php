<!-- chat box -->
<div class="row">
    <div class="col-md-3 pl-md-1 position-absolute" style="z-index: 11;bottom: 6.5vh;right: 0.6vw;">
        <div class="chat-popup" id="chatPopupModal" style="border-radius:10px;">
            <div class="ml-auto mr-auto rounded p-2 bg-white">
                <div class="row">
                    <div class="col-10 text-left">
                        <select class="selectpicker" id="chat_type" data-style="select-with-transition" data-size="4" data-width="100%" title="<?php echo e(__('header.group_chat')); ?>">
                            <option selected value="0"> <?php echo e(__('header.group_chat')); ?> </option>
                            <?php if(Auth::user()->id != $project->project_leader): ?>
                                <option value="<?php echo e($project->projectLeader->id); ?>">
                                    <?php if($project->projectLeader->deleted_at == null): ?>
                                        <?php echo e($project->projectLeader->first_name . ' ' . $project->projectLeader->last_name); ?>

                                    <?php else: ?>
                                        <?php echo e(__('header.user_deleted')); ?>

                                    <?php endif; ?>
                                </option>
                            <?php endif; ?>
                            <?php $__currentLoopData = $project->projectUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(Auth::user()->id != $project_user->user->id): ?>
                                    <option value="<?php echo e($project_user->user->id); ?>">
                                        <?php if($project_user->user->deleted_at == null): ?>
                                            <?php echo e($project_user->user->first_name . ' ' . $project_user->user->last_name); ?>

                                        <?php else: ?>
                                            <?php echo e(__('header.user_deleted')); ?>

                                        <?php endif; ?>
                                    </option>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-2 text-center">
                        <a href="javascript:void(0)" class="text-dark" onclick="closeChat()"><i class="fa fa-times pt-2"></i></a>
                    </div>
                </div>
                <div class="col-12 table-responsive" id="chat_body" style="max-height: 41vh;min-height: 41vh;">
                    <?php $__currentLoopData = $project->groupConversation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($conversation->message_type == 0): ?>
                            <div class="row mb-2">
                                <?php if($conversation->user->deleted_at == null): ?>
                                    <?php if($conversation->user->image == null): ?>
                                        <div class="col-2 mt-2 p-1 <?php echo e((Auth::user()->id == $conversation->user_id) ? 'order-10' : ''); ?>">
                                            <span class="p-2 rounded-circle bg-<?php echo e($theme); ?> text-white">
                                                <?php echo e(ucfirst(isset($conversation->user->first_name[0]) ? $conversation->user->first_name[0] : '') . ucfirst(isset($conversation->user->last_name[0]) ? $conversation->user->last_name[0] : '')); ?>

                                            </span>
                                        </div>
                                    <?php else: ?>
                                        <div class="col-2 p-1 <?php echo e((Auth::user()->id == $conversation->user_id) ? 'order-10' : ''); ?>">
                                            <img width="40" height="40" class="rounded-circle"
                                                 src="<?php echo e(Storage::disk('public')->exists($conversation->user->image) ? Storage::disk('public')->url($conversation->user->image) : asset('assets/img/faces/avatar.jpg')); ?>"/>
                                        </div>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <div class="col-2 mt-2 p-1">
                                        <span class="p-2 rounded-circle bg-<?php echo e($theme); ?> text-white">
                                            <i class="fas fa-user-slash"></i>
                                        </span>
                                    </div>
                                <?php endif; ?>
                                <div class="col-10 <?php echo e((Auth::user()->id == $conversation->user_id) ? 'order-2' : ''); ?>" style="background: #eeeeee;border-radius: 10px; ">
                                    <p class="mb-0 pb-0">
                                        <span style="font-size: 14px;">
                                            <b>
                                                <?php if($conversation->user && $conversation->user->deleted_at == null): ?>
                                                    <?php echo e($conversation->user->first_name . ' ' . $conversation->user->last_name); ?>

                                                <?php else: ?>
                                                    <?php echo e(__('header.user_deleted')); ?>

                                                <?php endif; ?>
                                            </b>
                                        </span>
                                        <span class="text-lowercase" style="float:right;font-size: 14px;"><b><?php echo e(getTime($conversation->created_at)); ?></b></span>
                                    </p>
                                    <p class="mb-0 pb-0 mt-0 pt-0" style="line-height: 20px;margin-top:5px;font-size: 12px;">
                                        <?php echo e(($conversation->message) ? $conversation->message : ''); ?>

                                        <?php if($conversation->document_id != '' && $conversation->document_id != null ): ?>
                                            <?php if($conversation->message): ?>
                                                <br>
                                            <?php endif; ?>
                                            <?php if($conversation->document->deleted_at == null): ?>
                                                <a href="<?php echo e(Storage::disk('public')->exists($conversation->document->file) ? Storage::disk('public')->url($conversation->document->file) : '#'); ?>" target="_blank" rel="tooltip"
                                                   title="<?php echo e($conversation->document->name); ?>" class="btn btn-link bg-transparent text-dark p-1 mt-0 mb-0 0 ml-0 mr-0 w-auto">
                                                    <?php echo getIcon($conversation->document->type); ?>

                                                </a>
                                            <?php else: ?>
                                                <?php echo e(__('header.file_deleted')); ?>

                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <p>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="col-12 table-responsive" id="individual_chat_body" style="max-height: 41vh;min-height: 41vh; display: none;"></div>

                <div class="box-footer">
                    <form id="chat_form" class="mb-0" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" class="message_type" value="0" name="message_type">
                        <input type="hidden" class="project_id" value="<?php echo e($project->id); ?>" name="project_id">
                        <input type="hidden" class="receiver_id" value="0" name="receiver_id">
                        <div class="input-group" style="border: 1px solid #bbb2b2; border-radius: 10px;padding:3px;background: #eeeeee;">
                            <input type="text" name="message" id="chat_message" placeholder="<?php echo e(__('header.write_something_interesting')); ?>" class="form-control" style="background-image:none;">
                            <div class="input-group-append">
                                <span class="input-group-text p-1">
                                    <label for="chat_file" rel="tooltip" title="Attach file" class="m-0">
                                        <span class="cursor-pointer"><i class="fas fa-paperclip text-dark" style="font-size: 17px"></i>
                                            <input type="file" id="chat_file" name="file" style="display:none">
                                        </span>
                                    </label>
                                </span>
                                <span class="input-group-text p-1">
                                    <button class="text-dark btn-link btn bg-transparent p-0 m-0" id="chat_btn" type="submit"><i class="fa fa-send m-0"></i></button>
                                </span>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- binnecle box -->
<div class="row">
    <div class="col-md-3 pl-md-1 position-absolute" style="z-index: 11;bottom: 6.5vh;right: 0.6vw;">
        <div class="chat-popup" id="binancePopupModal" style="border-radius:10px;">
            <div class="ml-auto mr-auto rounded p-2 bg-white">
                <div class="row">
                    <div class="col-10 text-left">
                        <h5><b><?php echo e(__('header.binnacle')); ?></b></h5>
                    </div>
                    <div class="col-2 text-center">
                        <a href="javascript:void(0)" class="text-dark" onclick="closeBinance()"><i class="fa fa-times pt-2"></i></a>
                    </div>
                </div>
                <div class="col-12 table-responsive" id="binance_body" style="max-height: 41vh;min-height: 41vh;">
                    <?php $__currentLoopData = $project->groupConversation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($conversation->message_type == 1): ?>
                            <div class="row mb-2">
                                <?php if($conversation->user->deleted_at == null): ?>
                                    <?php if($conversation->user->image == null): ?>
                                        <div class="col-2 mt-2 p-1 <?php echo e((Auth::user()->id == $conversation->user_id) ? 'order-10' : ''); ?>">
                                            <span class="p-2 rounded-circle bg-<?php echo e($theme); ?> text-white">
                                                <?php echo e(ucfirst(isset($conversation->user->first_name[0]) ? $conversation->user->first_name[0] : '') . ucfirst(isset($conversation->user->last_name[0]) ? $conversation->user->last_name[0] : '')); ?>

                                            </span>
                                        </div>
                                    <?php else: ?>
                                        <div class="col-2 p-1 <?php echo e((Auth::user()->id == $conversation->user_id) ? 'order-10' : ''); ?>">
                                            <img width="40" height="40" class="rounded-circle"
                                                 src="<?php echo e(Storage::disk('public')->exists($conversation->user->image) ? Storage::disk('public')->url($conversation->user->image) : asset('assets/img/faces/avatar.jpg')); ?>"/>
                                        </div>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <div class="col-2 mt-2 p-1">
                                        <span class="p-2 rounded-circle bg-<?php echo e($theme); ?> text-white">
                                            <i class="fas fa-user-slash"></i>
                                        </span>
                                    </div>
                                <?php endif; ?>
                                <div class="col-10 <?php echo e((Auth::user()->id == $conversation->user_id) ? 'order-2' : ''); ?>" style="background: #eeeeee;border-radius: 10px; ">
                                    <p class="mb-0 pb-0">
                                        <span style="font-size: 14px;">
                                            <b>
                                                <?php if($conversation->user && $conversation->user->deleted_at == null): ?>
                                                    <?php echo e($conversation->user->first_name . ' ' . $conversation->user->last_name); ?>

                                                <?php else: ?>
                                                    <?php echo e(__('header.user_deleted')); ?>

                                                <?php endif; ?>
                                            </b>
                                        </span>
                                        <span class="text-lowercase" style="float:right;font-size: 14px;"><b><?php echo e(getTime($conversation->created_at)); ?></b></span>
                                    </p>
                                    <p class="mb-0 pb-0 mt-0 pt-0" style="line-height: 20px;margin-top:5px;font-size: 12px;">
                                        <?php echo e(($conversation->message) ? $conversation->message : ''); ?>

                                        <?php if($conversation->document_id != '' && $conversation->document_id != null ): ?>
                                            <?php if($conversation->message): ?>
                                                <br>
                                            <?php endif; ?>
                                            <?php if($conversation->document->deleted_at == null): ?>
                                                <a href="<?php echo e(Storage::disk('public')->exists($conversation->document->file) ? Storage::disk('public')->url($conversation->document->file) : '#'); ?>" target="_blank" rel="tooltip"
                                                   title="<?php echo e($conversation->document->name); ?>" class="btn btn-link bg-transparent text-dark p-1 mt-0 mb-0 0 ml-0 mr-0 w-auto">
                                                    <?php echo getIcon($conversation->document->type); ?>

                                                </a>
                                            <?php else: ?>
                                                <?php echo e(__('header.file_deleted')); ?>

                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <p>
                                </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <div class="box-footer">
                    <form id="binance_form" class="mb-2" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" class="message_type" value="1" name="message_type">
                        <input type="hidden" class="project_id" value="<?php echo e($project->id); ?>" name="project_id">
                        <input type="hidden" class="receiver_id" value="0" name="receiver_id">
                        <div class="input-group" style="border: 1px solid #bbb2b2; border-radius: 10px;padding:3px;background: #eeeeee;">
                            <input type="text" name="message" id="binance_message" placeholder="<?php echo e(__('header.write_something_interesting')); ?>" class="form-control" style="background-image:none;">
                            <div class="input-group-append">
                                <span class="input-group-text p-1">
                                    <label for="binance_file" rel="tooltip" title="Attach file" class="m-0">
                                        <span class="cursor-pointer"><i class="fas fa-paperclip text-dark" style="font-size: 17px"></i>
                                            <input type="file" id="binance_file" name="file" style="display:none">
                                        </span>
                                    </label>
                                </span>
                                <span class="input-group-text p-1">
                                    <button class="text-dark btn-link btn bg-transparent p-0 m-0" id="binance_btn" type="submit"><i class="fa fa-send m-0"></i></button>
                                </span>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\projecto\resources\views/backend/user/project/chat/index.blade.php ENDPATH**/ ?>