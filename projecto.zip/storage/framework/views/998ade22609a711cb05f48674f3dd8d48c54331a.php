
<!-- Task Notes Modal -->
<div class="modal fade" id="taskNotesModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-md pb-0 mb-0">
        <div class="modal-content">

            <div class="card card-signup card-plain">
                <div class="modal-header card-header card-header-<?php echo e($theme); ?> rounded" style="    width: 90%; left: 5%;">
                    <h4 class="modal-title font-weight-bold"><?php echo e(__('header.add_note')); ?></h4>
                    <a type="button" class="text-white" style="top:0" data-dismiss="modal" aria-hidden="true"> <i class="material-icons">clear</i> </a>
                </div>
            </div>

            <form method="post" id="taskNotesForm" data-action="<?php echo e(route('task-note.store')); ?>" data-name="taskNotes">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="project_id" value="<?php echo e($project->id); ?>">
                <div class="modal-body card-body scroll-bar">
                    <select class="selectpicker" data-size="7" data-style="select-with-transition" title="<?php echo e(__('header.select_task')); ?>" data-container="body" name="task_id" required>
                        <option disabled><?php echo e(__('header.select_task')); ?>}</option>
                        <?php $__currentLoopData = $project->task; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($task->id); ?>"> <?php echo e($task->name); ?> </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <textarea class="form-control mt-3" name="notes" cols="30" rows="3" aria-placeholder="<?php echo e(__('header.add_notes')); ?>" required></textarea>

                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success ml-auto">
                        <?php echo e(__('header.add')); ?>

                    </button>
                    <button type="button" class="btn btn-danger btn-link mr-auto" data-dismiss="modal">
                        <?php echo e(__('header.close')); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>
</div><!--  End Modal -->

<?php /**PATH C:\xampp\htdocs\projecto\resources\views/backend/user/project/extras/add-task-notes.blade.php ENDPATH**/ ?>