<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <?php echo $__env->make('include.backend.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <style>
            .dropdown-menu .dropdown-item:hover, .dropdown-menu .dropdown-item:focus, .dropdown-menu a:hover, .dropdown-menu a:focus, .dropdown-menu a:active {
                box-shadow: 0 4px 20px 0px <?php echo e('#' . getThemeColor( $theme ) . '24'); ?>, 0 7px 10px -5px<?php echo e('#' . getThemeColor( $theme ) . '66'); ?>;
                background-color: <?php echo e('#' . getThemeColor( $theme )); ?>;
            }

            .bootstrap-select .dropdown-item.active {
                background: <?php echo e('#' . getThemeColor( $theme )); ?>;
            }

            .bootstrap-select .btn.dropdown-toggle.select-with-transition {
                background-image: linear-gradient(to top, <?php echo e('#' . getThemeColor( $theme )); ?> 2px, rgba(54, 186, 175, 0) 2px), linear-gradient(to top, #d2d2d2 1px, rgba(210, 210, 210, 0) 1px);
            }

            .pagination > .page-item.active > a, .pagination > .page-item.active > a:focus, .pagination > .page-item.active > a:hover, .pagination > .page-item.active > span, .pagination > .page-item.active > span:focus, .pagination > .page-item.active > span:hover {
                background-color: <?php echo e('#' . getThemeColor( $theme )); ?>;
                border-color: <?php echo e('#' . getThemeColor( $theme )); ?>;
                box-shadow: 0 4px 5px 0 <?php echo e('#' . getThemeColor( $theme ) . '24'); ?>, 0 1px 10px 0 <?php echo e('#' . getThemeColor( $theme ) . '1F'); ?>, 0 2px 4px -1px<?php echo e('#' . getThemeColor( $theme ) . '33'); ?>;
            }

            .form-control, .is-focused .form-control {

                background-image: linear-gradient(to top, <?php echo e('#' . getThemeColor( $theme )); ?> 2px, rgba(54, 186, 175, 0) 2px), linear-gradient(to top, #d2d2d2 1px, rgba(210, 210, 210, 0) 1px);
            }

            .card-collapse .card-header a:hover, .card-collapse .card-header a:active, .card-collapse .card-header a[aria-expanded="true"] {
                color: <?php echo e('#' . getThemeColor( $theme )); ?>;
            }
        </style>
        <?php echo $__env->yieldContent('style'); ?>
    </head>
    <body class="text-capitalize <?php echo e((Auth::user()->sidebar_size == 1) ? 'sidebar-mini' : ''); ?>">
        <div class="text-center spinner-overlay">
            <div class="spinner-grow spinner text-<?php echo e($theme); ?>" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <div class="wrapper" style="height: auto;">
            <?php echo $__env->make('include.backend.user.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="main-panel" style="height: auto">

                <?php echo $__env->make('include.backend.user.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="content pt-0 pb-0">
                    <?php echo $__env->yieldContent('content'); ?>
                    <?php echo $__env->make('include.backend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            </div>
        </div>
        

        <?php echo $__env->make('include.backend.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('include.backend.user.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('script'); ?>

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\projecto\resources\views/layouts/user.blade.php ENDPATH**/ ?>