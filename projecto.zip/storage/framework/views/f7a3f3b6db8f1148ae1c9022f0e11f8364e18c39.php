<!-- Add New TaskModal -->
<div class="modal fade" id="addNewTaskModal" tabindex="-1" role="dialog" aria-hidden="true" style="z-index: 11111111111111111;">
    <div class="modal-dialog modal-md pb-0 mb-0">
        <div class="modal-content">

            <div class="card card-signup card-plain">
                <div class="modal-header card-header card-header-<?php echo e($theme); ?> rounded" style="    width: 90%; left: 5%;">
                    <h4 class="modal-title font-weight-bold"><?php echo e(__('header.add_new_task')); ?></h4>
                    <a type="button" class="text-white" style="top:0" data-dismiss="modal" aria-hidden="true"><i class="material-icons">clear</i></a>
                </div>
            </div>

            <form action="" method="post" id="addNewTaskForm">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="project_id" value="<?php echo e($project->id); ?>">
                <div class="modal-body card-body scroll-bar" style="height: 63vh;overflow: auto;">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label for="exampleEmail" class="bmd-label-floating">
                                    <?php echo e(__('header.task_name')); ?>

                                </label>
                                <input type="text" class="form-control" name="name" required value="<?php echo e(old('name')); ?>">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label class="error">
                                    <?php echo e($message); ?>

                                </label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group <?php $__errorArgs = ['team_members'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <select class="selectpicker" name="team_members[]" id="team_members" multiple data-style="select-with-transition" data-size="4" data-width="100%" title="<?php echo e(__('header.choose_members')); ?>">
                                    <option disabled> <?php echo e(__('header.choose_members')); ?> </option>
                                    <?php $__currentLoopData = $project->projectUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $projectUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($projectUser->user->hasRole('User') && $projectUser->user->id != Auth::user()->id && $projectUser->user->deleted_at == null): ?>
                                            <option value="<?php echo e($projectUser->user->id); ?>" <?php echo e((in_array($projectUser->user->id, old('team_members', []))) ? 'selected' : ''); ?>>
                                                <?php echo e($projectUser->user->first_name . ' ' . $projectUser->user->last_name); ?>

                                            </option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['team_members'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label class="error">
                                    <?php echo e($message); ?>

                                </label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label for="start_date" class="bmd-label-floating">
                                    <?php echo e(__('header.start_date')); ?>

                                </label>
                                <input type="text" class="form-control date_picker start_date" name="start_date" id="start_date" required value="<?php echo e(old('start_date')); ?>">
                                <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label class="error">
                                    <?php echo e($message); ?>

                                </label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label for="end_date" class="bmd-label-floating">
                                    <?php echo e(__('header.end_date')); ?>

                                </label>
                                <input type="text" class="form-control date_picker end_date" name="end_date" id="end_date" required value="<?php echo e(old('end_date')); ?>">
                                <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label class="error">
                                    <?php echo e($message); ?>

                                </label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="form-group <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label for="exampleEmail" class="bmd-label-floating">
                                    <?php echo e(__('header.brief_description_of_task')); ?>

                                </label> <textarea name="description" cols="30" rows="2" class="form-control"><?php echo e(old('description')); ?></textarea>
                                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label class="error">
                                    <?php echo e($message); ?>

                                </label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-md-12" id="actions">
                            <p for="actions" class="bmd-label-floating">
                                <span><?php echo e(__('header.actions_max')); ?></span>
                                <span class="pull-right"><i class="fa fa-plus text-success cursor-pointer add_action"></i></span>
                            </p>

                            <div class="added_action mb-3">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text action_counter">1</span>
                                    </div>
                                    <input type="text" class="form-control text-capitalize" required name="action[]" placeholder="<?php echo e(__('header.add_action')); ?>">
                                </div>






                            </div>
                            <?php $__errorArgs = ['action'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <label class="error">
                                <?php echo e($message); ?>

                            </label>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-success ml-auto mr-auto">
                        <?php echo e(__('header.add')); ?>

                    </button>
                </div>
            </form>
        </div>
    </div>
</div><!--  End Modal -->

<?php /**PATH C:\xampp\htdocs\projecto\resources\views/backend/user/project/task/add.blade.php ENDPATH**/ ?>