
<div class="modal fade" id="completedTaskModal" tab index="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <div class="card card-signup card-plain">
                <div class="modal-header card-header card-header-<?php echo e($theme); ?> rounded" style="    width: 90%; left: 5%;">
                    <h4 class="modal-title font-weight-bold"><?php echo e(__('header.completed_tasks')); ?></h4>
                    <a type="button" class="text-white" style="top:0" data-dismiss="modal" aria-hidden="true"><i class="material-icons">clear</i></a>
                </div>
            </div>

            <div class="modal-body card-body scroll-bar row m-0 overflow-auto" id="complete_task_div" style="max-height: 40vh">
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                

                
                
                
                
                
                


                
                
                
                
                
                
                
                
                
                
                
                
                

                
                
                
                
            </div>
        </div>
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\projecto\resources\views/backend/user/project/task/completed.blade.php ENDPATH**/ ?>