<?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($task->status == 'completed'): ?>
        <div class="col-6">
            <?php endif; ?>
            <div class="bg-light p-2 mb-3 <?php echo e(($task->status == 'pending') ? 'bg-pending' : ''); ?> <?php echo e((auth()->user()->id == $task->added_by) ? '' : 'other_tasks'); ?>">
                <!-- <h6 class="h6css" >Lorem</h6> -->
                <a class="task_details" href="<?php echo e(route('task.show',$task->id)); ?>" data-id="<?php echo e($task->id); ?>">
                    <div class="d-flex align-items-center justify-content-start flex-wrap mb-1">
                        <span class="bg-light rounded mr-1 p-1 h6css mr-auto text-dark" title="<?php echo e(__('header.task_name')); ?>"><b><?php echo e($task->name); ?></b></span>
                        <?php $counter = 0; ?>
                        <?php if(Auth::user()->id != $task->addedBy->id): ?>
                            <?php $counter++; ?>
                            <?php if($task->addedBy->deleted_at == null): ?>
                                <span class="bg-light rounded mr-2 position-relative appended_tooltip" rel="tooltip" title="<?php echo e($task->addedBy->first_name . ' ' . $task->addedBy->last_name); ?>">
                                    <?php if($task->addedBy->image == null): ?>
                                        <span class="p-1 rounded-circle bg-<?php echo e($theme); ?> text-white">
                                            <?php echo e(ucfirst(isset($task->addedBy->first_name[0]) ? $task->addedBy->first_name[0] : '') . ucfirst(isset($task->addedBy->last_name[0]) ? $task->addedBy->last_name[0] : '')); ?>

                                        </span>
                                    <?php else: ?>
                                        <img width="25" height="25" class="rounded-circle"
                                             src="<?php echo e(Storage::disk('public')->exists($task->addedBy->image) ? Storage::disk('public')->url($task->addedBy->image) : asset('assets/img/faces/avatar.jpg')); ?>"/>
                                    <?php endif; ?>
                                    <span class="online_status_<?php echo e($task->addedBy->id); ?> logged-<?php echo e(($task->addedBy->isOnline()) ? 'in' : 'out'); ?>">●</span>
                                </span>
                            <?php else: ?>
                                <span class="bg-light rounded mr-2 position-relative appended_tooltip" rel="tooltip" title="<?php echo e(__('header.user_deleted')); ?>">
                                    <span class="p-1 rounded-circle bg-<?php echo e($theme); ?> text-white">
                                        <i class="fas fa-user-slash"></i>
                                    </span>
                                    <span class="logged-out">●</span>
                                </span>
                            <?php endif; ?>
                        <?php endif; ?>
                        <?php $__currentLoopData = $task->taskUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(Auth::user()->id != $user->user->id): ?>
                                <?php $counter++; ?>
                                <?php if($user->user->deleted_at == null): ?>
                                    <?php if($counter <= 3): ?>
                                        <span class="bg-light rounded mr-2 position-relative appended_tooltip" rel="tooltip" title="<?php echo e($user->user->first_name . ' ' . $user->user->last_name); ?>">
                                            <?php if($user->user->image == null): ?>
                                                <span
                                                    class="p-1 rounded-circle bg-<?php echo e($theme); ?> text-white"> <?php echo e(ucfirst(isset($user->user->first_name[0]) ? $user->user->first_name[0] : '') . ucfirst(isset($user->user->last_name[0]) ? $user->user->last_name[0] : '')); ?> </span>
                                            <?php else: ?>
                                                <img width="25" height="25" class="rounded-circle"
                                                     src="<?php echo e(Storage::disk('public')->exists($user->user->image) ? Storage::disk('public')->url($user->user->image) : asset('assets/img/faces/avatar.jpg')); ?>"/>
                                            <?php endif; ?>
                                            <span class="online_status_<?php echo e($user->user->id); ?> logged-<?php echo e(($user->user->isOnline()) ? 'in' : 'out'); ?>">●</span>
                                        </span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="bg-light rounded mr-2 position-relative appended_tooltip" rel="tooltip" title="<?php echo e(__('header.user_deleted')); ?>">
                                        <span class="p-1 rounded-circle bg-<?php echo e($theme); ?> text-white">
                                            <i class="fas fa-user-slash"></i>
                                        </span>
                                        <span class="logged-out">●</span>
                                    </span>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($counter > 3): ?>
                            <span class="bg-light rounded mr-1 p-1"><i class="fa fa-plus"></i></span>
                        <?php endif; ?>
                    </div>
                </a>

                <div class="card pl-2 pr-2 pt-1 pb-1 m-0 rounded bg-light appended_tooltip" rel="tooltip" title="<?php echo e(__('header.progress')); ?> <?php echo e((int)$task->progress); ?>%">
                    <div class="progress m-0">
                        <div class="progress-bar bg-<?php echo e($theme); ?>" role="progressbar" style="width: <?php echo e((int)$task->progress); ?>%" aria-valuenow="<?php echo e((int)$task->progress); ?>" aria-valuemin="0" aria-valuemax="100"></div>
                    </div>
                </div>

                <div class="d-flex align-items-center justify-content-between mt-2">
                    <span class="fs-12"><?php echo e(__('header.actions')); ?></span>
                    <span class="fs-12">
                        <?php if($task->taskAction!=null && $task->taskAction->count()>0): ?>
                            <?php echo e($task->taskAction->where('status','completed')->count()); ?>

                            / <?php echo e($task->taskAction->count()); ?>

                        <?php else: ?> 0/0
                        <?php endif; ?>
                    </span>
                    <span class="fs-12"><i class="fas fa-clock"></i>
                        <?php if($task->status == 'completed'): ?>
                            <?php echo e(__('header.completed')); ?>

                            <?php else: ?>
                        <?php
                            $startTime = Carbon\Carbon::parse($task->start_date);
                            $endTime = Carbon\Carbon::parse($task->end_date);
                            echo   $endTime->diffForHumans($startTime,true).' ' . __('header.left');
                        ?>
                            <?php endif; ?>
                    </span>
                </div>

            </div>
            <?php if($task->status == 'completed'): ?>
        </div>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\projecto\resources\views/backend/user/project/task/load.blade.php ENDPATH**/ ?>