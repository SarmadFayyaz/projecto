
<div class="modal fade" id="createEventModal" tab index="-1" role="dialog" aria-hidden="true" style="z-index: 1111111;">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">

            <div class="card card-signup card-plain">
                <div class="modal-header card-header card-header-<?php echo e($theme); ?> rounded" style="    width: 90%; left: 5%;">
                    <h4 class="modal-title font-weight-bold"><?php echo e(__('header.create_event')); ?></h4>
                    <a type="button" class="text-white" style="top:0" data-dismiss="modal" aria-hidden="true"><i class="material-icons">clear</i></a>
                </div>
            </div>

            <div class="modal-body card-body scroll-bar">
                <form method="POST" id="createEventForm">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="project_id" value="<?php echo e($project->id); ?>">
                    <div class="row justify-content-center">

                        <div class="col-5">
                            <select class="selectpicker user_id" data-style="select-with-transition" name="user_id[]" required multiple title="<?php echo e(__('header.choose_members')); ?>" data-size="4" data-container="body">
                                <option disabled> <?php echo e(__('header.choose_members')); ?> </option>
                                <?php $__currentLoopData = $project->projectUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($project_user->user_id); ?>"><?php echo e($project_user->user->first_name . ' '  .$project_user->user->last_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="col-10 mb-3">
                            <div class="form-group <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label for="title" class="bmd-label-floating"><?php echo e(__('header.title')); ?></label>
                                <input type="text" class="form-control title m-0" name="title" required>
                                <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label class="error">
                                    <?php echo e($message); ?>

                                </label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-5">
                            <div class="form-group <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label for="start_date" class="bmd-label-floating"><?php echo e(__('header.start_date')); ?></label>
                                <input type="text" name="start_date" class="form-control date_picker" required>
                                <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label class="error">
                                    <?php echo e($message); ?>

                                </label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-5">
                            <div class="form-group <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label for="end_date" class="bmd-label-floating"><?php echo e(__('header.end_date')); ?></label>
                                <input type="text" name="end_date" class="form-control date_picker" required>
                                <?php $__errorArgs = ['end_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label class="error">
                                    <?php echo e($message); ?>

                                </label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-5">
                            <div class="form-group <?php $__errorArgs = ['start_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label for="start_time" class="bmd-label-floating"><?php echo e(__('header.start_time')); ?></label>
                                <input type="text" name="start_time" class="form-control start_time time_picker" required autocomplete="off">
                                <?php $__errorArgs = ['start_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label class="error">
                                    <?php echo e($message); ?>

                                </label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-5">
                            <div class="form-group <?php $__errorArgs = ['end_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <label for="end_time" class="bmd-label-floating"><?php echo e(__('header.end_time')); ?></label>
                                <input type="text" name="end_time" class="form-control end_time time_picker" required autocomplete="off">
                                <?php $__errorArgs = ['end_time'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label class="error">
                                    <?php echo e($message); ?>

                                </label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-5">
                            <div class="form-group <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <select class="selectpicker event_type" data-style="select-with-transition" name="type" required title="<?php echo e(__('header.select_event_type')); ?>" data-size="4" data-container="body">
                                    <option value="1"> <?php echo e(__('header.occurring_once')); ?> </option>
                                    <option value="2"> <?php echo e(__('header.recurring_event')); ?> </option>
                                </select>
                                <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label class="error">
                                    <?php echo e($message); ?>

                                </label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="col-5 recur_event_div" hidden>
                            <div class="form-group <?php $__errorArgs = ['days_of_week'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> has-danger <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <select class="selectpicker" data-style="select-with-transition" name="days_of_week[]" multiple title="<?php echo e(__('header.select_days')); ?>" data-size="4" data-container="body">
                                    <option value="0"> <?php echo e(__('header.sunday')); ?> </option>
                                    <option value="1"> <?php echo e(__('header.monday')); ?> </option>
                                    <option value="2"> <?php echo e(__('header.tuesday')); ?> </option>
                                    <option value="3"> <?php echo e(__('header.wednesday')); ?> </option>
                                    <option value="4"> <?php echo e(__('header.thursday')); ?> </option>
                                    <option value="5"> <?php echo e(__('header.friday')); ?> </option>
                                    <option value="6"> <?php echo e(__('header.saturday')); ?> </option>
                                </select>
                                <?php $__errorArgs = ['days_of_week'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label class="error">
                                    <?php echo e($message); ?>

                                </label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div class="col-12 text-center">
                            <button type="submit" class="btn btn-success"><?php echo e(__('header.add')); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\projecto\resources\views/backend/user/project/calendar/create.blade.php ENDPATH**/ ?>