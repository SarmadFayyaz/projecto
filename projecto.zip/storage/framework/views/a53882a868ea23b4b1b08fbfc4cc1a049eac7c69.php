<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <?php echo $__env->make('include.backend.auth.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body class="text-capitalize">

        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->make('include.backend.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('script'); ?>

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\projecto\resources\views/layouts/auth.blade.php ENDPATH**/ ?>