<div class="row mb-2">
    <div class="col-4">
        <label> <?php echo e(__('header.project_name')); ?>: </label>
    </div>
    <div class="col-8">
        <label class="font-weight-bold text-dark"> <?php echo e($event->project->name); ?> </label>
    </div>
</div>
<div class="row mb-2">
    <div class="col-4">
        <label> <?php echo e(__('header.title')); ?>: </label>
    </div>
    <div class="col-8">
        <label class="font-weight-bold text-dark"> <?php echo e($event->title); ?> </label>
    </div>
</div>
<div class="row mb-2">
    <div class="col-4">
        <label> <?php echo e(__('header.user')); ?>: </label>
    </div>
    <div class="col-8">
        <ul class="list-group">
            <?php $__currentLoopData = $event->eventUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventUser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="list-group-item">
                    <label class="font-weight-bold text-dark"> <?php echo e($eventUser->user->first_name . ' ' . $eventUser->user->last_name); ?> </label>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<div class="row mb-2">
    <div class="col-4">
        <label> <?php echo e(__('header.date')); ?>: </label>
    </div>
    <div class="col-8">
        <label class="font-weight-bold text-dark"> <?php echo e($event->start_date . ' - ' . $event->end_date); ?> </label>
    </div>
</div>
<div class="row mb-3">
    <div class="col-4">
        <label> <?php echo e(__('header.time')); ?>: </label>
    </div>
    <div class="col-8">
        <label class="font-weight-bold text-dark"> <?php echo e($event->start_time . ' - ' . $event->end_time); ?> </label>
    </div>
</div>
<div class="row mb-3">
    <div class="col-4">
        <label> <?php echo e(__('header.event_type')); ?>: </label>
    </div>
    <div class="col-8">
        <label class="font-weight-bold text-dark"> <?php echo e(($event->type == 1) ? __('header.occurring_once') : __('header.recurring_event')); ?> </label>
    </div>
</div>
<?php if($event->type == 2): ?>
    <div class="row mb-3">
        <div class="col-4">
            <label> <?php echo e(__('header.recurring_days')); ?>: </label>
        </div>
        <div class="col-8">
            <label class="font-weight-bold text-dark">
                <?php $__currentLoopData = json_decode($event->days_of_week); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e(getDay($day)); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </label>
        </div>
    </div>
<?php endif; ?>
<div class="row text-center">
    <div class="col">
        <a href="<?php echo e(route('event.edit', $event->id)); ?>" data-modal-id="#editEventModal" class="btn btn-primary event_edit"><?php echo e(__('header.edit')); ?></a>
        <a href="<?php echo e(route('event.destroy', $event->id)); ?>" data-event="delete" class="btn btn-danger"><?php echo e(__('header.delete')); ?></a>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\projecto\resources\views/backend/user/dashboard/calendar/show.blade.php ENDPATH**/ ?>