<?php

return array (
  'userManagement' => 
  array (
    'title' => 'User management',
    'title_singular' => 'User management',
  ),
  'permission' => 
  array (
    'title' => 'Permissions',
    'title_singular' => 'Permission',
    'fields' => 
    array (
      'id' => 'ID',
      'id_helper' => '',
      'title' => 'Title',
      'title_helper' => '',
      'created_at' => 'Created at',
      'created_at_helper' => '',
      'updated_at' => 'Updated at',
      'updated_at_helper' => '',
      'deleted_at' => 'Deleted at',
      'deleted_at_helper' => '',
    ),
  ),
  'role' => 
  array (
    'title' => 'Roles',
    'title_singular' => 'Role',
    'fields' => 
    array (
      'id' => 'ID',
      'id_helper' => '',
      'title' => 'Title',
      'title_helper' => '',
      'permissions' => 'Permissions',
      'permissions_helper' => '',
      'created_at' => 'Created at',
      'created_at_helper' => '',
      'updated_at' => 'Updated at',
      'updated_at_helper' => '',
      'deleted_at' => 'Deleted at',
      'deleted_at_helper' => '',
    ),
  ),
  'user' => 
  array (
    'title' => 'Users',
    'title_singular' => 'User',
    'fields' => 
    array (
      'id' => 'ID',
      'id_helper' => '',
      'name' => 'Name',
      'name_helper' => '',
      'email' => 'Email',
      'email_helper' => '',
      'email_verified_at' => 'Email verified at',
      'email_verified_at_helper' => '',
      'password' => 'Password',
      'password_helper' => '',
      'roles' => 'Roles',
      'roles_helper' => '',
      'remember_token' => 'Remember Token',
      'remember_token_helper' => '',
      'created_at' => 'Created at',
      'created_at_helper' => '',
      'updated_at' => 'Updated at',
      'updated_at_helper' => '',
      'deleted_at' => 'Deleted at',
      'deleted_at_helper' => '',
    ),
  ),
);
