<?php

return array (
  'reset' => 'Your password has been reset!',
);
